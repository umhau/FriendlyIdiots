Installation: 

1. Run: fabric-installer-0.11.1.exe. 

	1b. Choose minecraft version 1.19.2 and the default loader version, and press 'install'.

2. Run: ZeroTier One.msi.

	2b. Go to discord or your text messages and get the 'network id' of our server.

	2c. Zerotier will put a new icon in your taskbar. 

	2d. Right click the icon, select 'join network', and paste in the 'network id'.

        2e. When the 'Friendly Idiots' network is visible in the right click menu, you're connected.

3. Copy the folders 'mods' and 'resourcepacks'.

	3b. Go to: C:\Users\%username%\AppData\Roaming\.minecraft

	3c. Paste the 'mods' and 'resourcepacks' folders into the '.minecraft' folder.

4. Launch minecraft. 

	4b. You should see a new installation option for 'fabric 1.19.2'. Use that.

	4c. At the Multiplayer vs Singleplayer selection window, choose 'options' -> 'resource packs'. 

	4d. Select the resource packs 'OliverRemund' and 'RenaissanceAndBaroque'.

9. Open the server.