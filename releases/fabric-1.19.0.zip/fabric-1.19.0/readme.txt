Installation: 

1. Run: fabric-installer-0.11.0.exe. 

2. Choose minecraft version 1.19 and the default loader version, and press 'install'.

3. Copy the folders 'mods' and 'resourcepacks'.

4. Go to: C:\Users\%username%\AppData\Roaming\.minecraft

5. Paste the 'mods' and 'resourcepacks' folders into the '.minecraft' folder.

6. Launch minecraft. You should see a new installation option for 'fabric'. Use that.

7. At the Multiplayer vs Singleplayer selection window, choose 'options' -> 'resource packs'. 

8. Select the resource packs 'OliverRemund' and 'RenaissanceAndBaroque'.

9. Open the server.