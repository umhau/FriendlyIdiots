Installation: 

Run: fabric-installer-0.9.0.exe

Use the given defaults, and press 'install'.

Open the subfolder containing the mod files. Copy the files.

Go to the mod folder of your computer. It will be located somewhere similar to:

    C:\Users\BOB\AppData\Roaming\.minecraft

Create a subfolder here, called `mods`. The path to that folder should be

    C:\Users\BOB\AppData\Roaming\.minecraft\mods

Paste the mods you copied into here.

Now you can run the minecraft launcher. Use the 'fabric' version.  