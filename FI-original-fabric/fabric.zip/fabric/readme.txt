Installation: 

1. Run: fabric-installer-0.9.0.exe. 

2. Use the given defaults, and press 'install'.

3. Copy the folder 'mods'.

4. Go to: C:\Users\BOB\AppData\Roaming\.minecraft

5. Paste 'mods' into this folder.

6. Launch minecraft. You should see an option for 'fabric'. use that. 