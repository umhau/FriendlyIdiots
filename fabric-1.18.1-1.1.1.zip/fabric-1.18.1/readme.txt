Installation: 

1. Run: fabric-installer-0.10.2.exe. 

2. Use the given defaults, and press 'install'.

3. Copy the folder 'mods'.

4. Go to: C:\Users\YOUR_USERNAME\AppData\Roaming\.minecraft

5. Paste the 'mods' folder into the '.minecraft' folder. 

6. Launch minecraft. You should see a new installation option for 'fabric'. Use that.